package com.example.appbinder;

import android.os.Parcel;
import android.os.Parcelable;

public class ResponseData implements Parcelable {

    private String s;

    protected ResponseData(Parcel in) {
        readFromParcel(in);
    }

    public ResponseData(String s) {
       this.s = s;
    }

    /** 将数据写入到Parcel **/
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(s);
    }

    /** 从Parcel中读取数据 **/
    public void readFromParcel(Parcel in){
        s = in.readString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<ResponseData> CREATOR = new Creator<ResponseData>() {
        @Override
        public ResponseData createFromParcel(Parcel in) {
            return new ResponseData(in);
        }

        @Override
        public ResponseData[] newArray(int size) {
            return new ResponseData[size];
        }
    };

    @Override
    public String toString() {
        return s;
    }
}
