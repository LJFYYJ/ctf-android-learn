package com.example.appbinderclient;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.widget.TextView;

import com.example.appbinder.IMyAidlInterface;
import com.example.appbinder.RequestData;
import com.example.appbinder.ResponseData;

public class MainActivity extends AppCompatActivity {

    private IMyAidlInterface mAidlInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent in = new Intent();
        in.setComponent(new ComponentName("com.example.appbinder", "com.example.appbinder.MyService"));
        bindService(in, connD, Context.BIND_AUTO_CREATE);
    }

    private ServiceConnection connD = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mAidlInterface = IMyAidlInterface.Stub.asInterface(service);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mAidlInterface = null;
        }
    };

    public void send(android.view.View v) {
        try {
            ResponseData data = mAidlInterface.send(new RequestData("hello i'm client"));
            TextView textView = findViewById(R.id.textview);
            textView.setText(data.toString());
        } catch (Exception e) {

        }
    }
}