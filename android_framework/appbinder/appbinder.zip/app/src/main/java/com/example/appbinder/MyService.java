package com.example.appbinder;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

public class MyService extends Service {

    private final IMyAidlInterface.Stub mBinder = new IMyAidlInterface.Stub() {
        @Override
        public ResponseData send(RequestData data) throws RemoteException {
            Log.i("service","[RemoteService] receive  "+ data.toString());
            return new ResponseData("i'm service message");
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }
}
