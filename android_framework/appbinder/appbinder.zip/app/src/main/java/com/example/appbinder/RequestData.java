package com.example.appbinder;

import android.os.Parcel;
import android.os.Parcelable;

import static android.os.UserHandle.readFromParcel;

public class RequestData implements Parcelable {

    private String s;

    protected RequestData(Parcel in) {
        readFromParcel(in);
    }

    public RequestData(String s) {
        this.s = s;
    }

    /** 将数据写入到Parcel **/
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(s);
    }

    /** 从Parcel中读取数据 **/
    public void readFromParcel(Parcel in){
        s = in.readString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<RequestData> CREATOR = new Creator<RequestData>() {
        @Override
        public RequestData createFromParcel(Parcel in) {
            return new RequestData(in);
        }

        @Override
        public RequestData[] newArray(int size) {
            return new RequestData[size];
        }
    };

    @Override
    public String toString() {
        return s;
    }
}
